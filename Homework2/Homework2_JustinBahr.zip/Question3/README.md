This folder contains the following files:
1. README.md
2. makefile
3. Q3.cpp
4. Graph.cpp
5. Graph.h
6. Q3.pdf

Run the command "make" to generate the following executables:
1. Q3

Run the command "make clean" to delete the executables.