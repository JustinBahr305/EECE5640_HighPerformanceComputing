This folder contains the following files:
1. README.md
2. makefile
3. Q1_omp.cpp
4. Q1_leibniz_omp.cpp
5. Q1_pthread.cpp
6. Q1_leibniz_pthread
7. Q1.pdf

Run the command "make" to generate the following executables:
1. Q1_omp
2. Q1_leibniz_omp
3. Q1_pthread
4. Q1_leibniz_pthread

Run the command "make clean" to delete the executables.
