This folder contains the following files:
1. README.md
2. makefile
3. Q2_PthreadSort.cpp

Run the command "make" to generate the Q2_PthreadSort executable.
Input the number of threads to run with (1, 2, 4, 8, or 32).

Run the command "make clean" to delete the executable.
