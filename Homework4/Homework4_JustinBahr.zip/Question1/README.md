This folder contains the following files:
1. README.md
2. makefile
3. Q1.cpp
4. Q1.script
5. Q1.pdf

Run the command "make" to generate the following executable:
1. Q1

Run the command "make clean" to delete the executable.

To execute this MPI program, run the command "sbatch Q1.script".